﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound : MonoBehaviour
{
    public static Sound instance;
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip bgSound;
    [SerializeField] private AudioClip eatSound;
    [SerializeField] private AudioClip hurtSound;
    [SerializeField] private AudioClip dieSound;
    [SerializeField] private AudioClip satiSound;
    [SerializeField] private AudioClip winSound;
    [SerializeField] private AudioClip gameoverSound;
    private void Awake()
    {
        audioSource.Play();
        
    }
    private void Update()
    {
    }
    public void OnPlayerEat()
    {
        audioSource.PlayOneShot(eatSound);
    }
    public void OnPlayerSatisfied()
    {
        audioSource.PlayOneShot(satiSound);
    }
    public void OnPlayerHurt()
    {
        audioSource.PlayOneShot(hurtSound);
    }
    public void OnPlayerDie()
    {
        audioSource.PlayOneShot(dieSound);
    }
    public void OnWin()
    {
        audioSource.PlayOneShot(winSound);
    }
    public void OnGameover()
    {
        audioSource.PlayOneShot(gameoverSound);
    }
    public void bgsoundStop()
    {
        audioSource.Stop();
    }
}