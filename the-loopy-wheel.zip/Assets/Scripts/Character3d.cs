﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[RequireComponent(typeof(CharacterController))]
public class Character3d : MonoBehaviour
{
    // Variables
    [SerializeField] private CharacterController controller;
    [SerializeField] private float speed = 6f;
    [SerializeField] private float jumpSpeed = 5f;
    [SerializeField] private float smoothTurnTime = 0.1f;
    [SerializeField] private Transform cam;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayerMask = 0;
    [SerializeField] private float gravity = -30;
    [SerializeField] private float groundDistance = 0.4f;
    [SerializeField] private LayerMask unGround;
    [SerializeField] private int health = 8;
    [SerializeField] private Slider healthBar;
    [SerializeField] private GameObject panelGameOver;
    [SerializeField] private GameObject panelWin;
    private float turnSmoothVeloc;
    private bool isGrounded;
    private bool isTouchingUnGround;
    private Vector3 velocity;
    private Sound soundMgr;
    private int ConfigApple = 3;
    private void Start()
    {
        soundMgr = GetComponent<Sound>();
        PlayerPrefs.SetInt("AppleEaten", 0);
    }
    private void Update()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundLayerMask);
        isTouchingUnGround = Physics.CheckSphere(groundCheck.position, groundDistance, unGround);
        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }
        if (isTouchingUnGround)
        {
            Debug.Log("Is Touching UnTouchable ground;");
        }
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");
        Vector3 direction = new Vector3(horizontal, 0f, vertical).normalized;
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
        if (direction.magnitude >= 0.1f)
        {
            float tAng = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg + cam.eulerAngles.y;
            float ang = Mathf.SmoothDampAngle(transform.eulerAngles.y, tAng, ref turnSmoothVeloc, smoothTurnTime);
            transform.rotation = Quaternion.Euler(0f, ang, 0f);
            Vector3 movementDirection = Quaternion.Euler(0f, tAng, 0f) * Vector3.forward;
            controller.Move(movementDirection.normalized * speed * Time.deltaTime);
        }
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpSpeed * -2f * gravity);
        }
    }
    private void HandleHealth(int healthUnits, string type)
    {
        if (type == "+")
        {
            health += healthUnits;
            healthBar.value = health;
        }
        else
        {
            health -= healthUnits;
            healthBar.value = health;
        }
        GameOver();
    }
    private void GameOver()
    {
        if (health <= 0)
        {
            panelGameOver.SetActive(true);
            soundMgr.OnGameover();
            //soundMgr.bgsoundStop();
            //yield return new WaitForSeconds(5f);
            Time.timeScale = 0f;
        }
    }
    private void Win()
    {
        panelWin.SetActive(true);
        soundMgr.OnWin();
        //soundMgr.bgsoundStop();
        Time.timeScale = 0f;
    }
    private void OnTriggerEnter(Collider collider)
    {
        int appleCount = PlayerPrefs.GetInt("AppleEaten", 0);
        if (collider.CompareTag("Enemy"))
        {
            HandleHealth(3, "-");
            soundMgr.OnPlayerHurt();
        }
        if (collider.CompareTag("Prey"))
        {
            appleCount++;
            PlayerPrefs.SetInt("AppleEaten", appleCount);
            HandleHealth(1, "+");
            soundMgr.OnPlayerEat();
            //test.Instance.MyTest();
            if (appleCount == ConfigApple)
            {
                Win();
            }
        }
    }
}
