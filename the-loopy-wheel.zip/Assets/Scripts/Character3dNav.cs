﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Character3d))]
public class Character3dNav : MonoBehaviour
{
    /*[SerializeField] private LayerMask walkableMask;
    private Camera cam;
    private Character3d charac;
    private void Start()
    {
        cam = Camera.main;
        charac = GetComponent<Character3d>();
    }
    private void OnCollisionEnter(Collision collision)
    {
    }
    private void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 700, walkableMask))
            {
                Debug.Log("HIT: " + hit.collider.name + " " + hit.point);
                charac.MoveToPoint(hit.point);
            }
        }
    }*/
}
