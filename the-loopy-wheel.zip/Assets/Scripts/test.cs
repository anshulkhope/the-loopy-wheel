﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour
{
    public static test Instance;
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip testClip;
    // Start is called before the first frame update
    void Awake()
    {
        Instance = this;
    }

    // Update is called once per frame
    public void MyTest()
    {
        audioSource.PlayOneShot(testClip);
    }
}
