# the-loopy-wheel
​The Loopy Wheel is simple 3D spinning wheel game. Juno caterpilar is hungry and needs to eat apples. Avoid dangerous obstacles while wheel spins. Try to eat at least 3 apple to feed the Juno and win the game.
